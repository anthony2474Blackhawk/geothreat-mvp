import type { RiskClassification } from "@/domain/types";
export const riskClass=(r:RiskClassification)=>`risk-${r.toLowerCase().replace(" ","-")}`;
export function RiskPill({risk}:{risk:RiskClassification}){return <span className={`pill ${riskClass(risk)}`}>{risk}</span>}
export function ScoreRing({score}:{score:number}){return <div className="score-ring" style={{"--score":score} as React.CSSProperties}><strong>{score}</strong></div>}
