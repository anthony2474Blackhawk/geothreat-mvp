export interface WeightedScore { score: number; weight: number; confidence?: number; }
const clamp = (value: number) => Math.max(0, Math.min(100, value));
export function normalise(value: number, min: number, max: number, higherMeansHigherRisk = true): number {
  if (!Number.isFinite(value) || max <= min) throw new Error("Invalid normalisation inputs");
  const scaled = clamp(((value - min) / (max - min)) * 100);
  return Number((higherMeansHigherRisk ? scaled : 100 - scaled).toFixed(2));
}
export function weightedAverage(values: WeightedScore[]): number {
  const valid = values.filter(v => Number.isFinite(v.score) && Number.isFinite(v.weight) && v.weight > 0);
  if (!valid.length) throw new Error("At least one positively weighted score is required");
  const totalWeight = valid.reduce((sum, v) => sum + v.weight, 0);
  return Number((valid.reduce((sum, v) => sum + clamp(v.score) * v.weight, 0) / totalWeight).toFixed(2));
}
export function confidenceScore(values: WeightedScore[], completeness: number, recency: number, sourceReliability: number): number {
  const observed = values.filter(v => v.confidence !== undefined).map(v => ({ score: v.confidence!, weight: v.weight }));
  const indicatorConfidence = observed.length ? weightedAverage(observed) : 0;
  return weightedAverage([{score: indicatorConfidence, weight: .35}, {score: completeness, weight: .3}, {score: recency, weight: .2}, {score: sourceReliability, weight: .15}]);
}
export function classify(score: number): "Very Low" | "Low" | "Moderate" | "High" | "Critical" {
  const s=clamp(score); if(s<20)return "Very Low"; if(s<40)return "Low"; if(s<60)return "Moderate"; if(s<80)return "High"; return "Critical";
}
