export type RiskClassification = "Very Low" | "Low" | "Moderate" | "High" | "Critical";
export type Trend = "Improving" | "Stable" | "Deteriorating" | "Rapidly deteriorating";
export type Confidence = "Low" | "Medium" | "High";
export interface CategoryScore { slug: string; name: string; score: number; trend: Trend; }
export interface CountryRecord {
  isoCode: string; name: string; region: string; score: number; classification: RiskClassification;
  trend: Trend; confidence: Confidence; updatedAt: string; categoryScores: CategoryScore[];
  drivers: string[]; stabilisers: string[]; history: { period: string; score: number }[];
}
