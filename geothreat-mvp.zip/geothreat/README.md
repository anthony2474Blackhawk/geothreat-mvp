# GeoThreat MVP

GeoThreat is an explainable geopolitical-risk dashboard built from the supplied product specification. The current repository implements the first vertical slice: dashboard, 20-country demonstration dataset, country profiles, comparison, methodology, administrator-weight UI, Prisma model, scoring engine, API routes and unit tests.

## Important status

All displayed country values are **synthetic demonstration data**. They must not be used for travel, investment, security or policy decisions. Production ingestion must retain source, publisher, observation date, refresh date and confidence for each metric.

## Local setup

1. Install Node.js 20+ and Docker.
2. Copy `.env.example` to `.env`.
3. Start PostgreSQL: `docker compose up -d`.
4. Install dependencies: `npm install`.
5. Generate Prisma: `npm run db:generate`.
6. Create the schema: `npm run db:migrate -- --name init`.
7. Seed demonstration countries: `npm run db:seed`.
8. Run: `npm run dev` and open `http://localhost:3000`.

## Verification

Run `npm run typecheck`, `npm run lint`, `npm test`, and `npm run build`.

## Architecture

- `src/app`: App Router pages and API endpoints.
- `src/components`: reusable UI.
- `src/domain/scoring`: deterministic scoring logic.
- `src/data/demo.ts`: explicitly labelled demonstration data.
- `prisma`: PostgreSQL schema and seed.
- `tests`: unit tests.

## Implemented

Dashboard, country index, country profile, comparison, methodology, admin weight prototype, REST endpoints, Zod ISO validation, score normalisation, weighted calculation, classification, confidence helper, responsive states and PostgreSQL data model.

## Next increments

Connect UI reads to Prisma; add CSV import and source registry; add authentication/RBAC; persist weight edits with audit logs; add proper map geometry; implement missing/empty/error states per route; add source-level data quality views; add event review workflow.
